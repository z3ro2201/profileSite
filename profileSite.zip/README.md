# /blog 통합 (prologue + posts → /blog)

## 신규/리다이렉트
- `app/blog/page.tsx` — 새 메인 블로그 페이지 (prologue+posts 통합, 지난번 만든 BlogListClient 사용)
- `app/blog/posts/page.tsx` — `/blog`로 리다이렉트 (쿼리스트링 유지)
- `app/blog/prologue/page.tsx` — `/blog`로 리다이렉트

## 링크 정리
- `app/blog/layout.tsx`, `layout/blog/BlogListClient.tsx`, `layout/blog/blogLayout.tsx`, `layout/blog/BlogSSRShell.tsx`, `layout/admin/mainLayout.tsx`, `layout/Season3LayoutClient.tsx`, `app/sitemap.ts` — `/blog/posts`, `/blog/prologue` 참조 전부 `/blog`로 (상세 링크 `/blog/posts/view/[id]`는 그대로 유지)

## 덤으로 고친 것
`app/blog/page.tsx`로 옮기면서 봇용 JSON-LD가 `https://example.com/...`(가짜 도메인)을 쓰고 있던 걸 발견해서 `https://2er0.io`로 고쳤어요.

## 확인 필요
`app/blog/posts/page.tsx`가 리다이렉트로 바뀌면서, 혹시 이 URL을 외부(구글 등)에서 이미 색인해뒀다면 몇 주간 검색결과에 `/blog/posts`가 계속 뜨다가 서서히 `/blog`로 넘어갈 거예요 (301은 아니고 Next.js의 `redirect()`가 기본적으로 307/308을 쓰니 검색엔진이 정상적으로 새 URL을 학습합니다).

## 안 건드린 것
`layout/blog/blogClient.tsx`는 실제로 렌더링되지 않는 죽은 코드(`app/blog/layout.tsx`가 import만 하고 미사용)라 그대로 뒀습니다. 신경 쓰이시면 나중에 파일 자체를 지우셔도 돼요.

## 확인해본 것
`tsc --noEmit`, `eslint` 전체 baseline(26/164) 그대로, 새로 깨진 곳 없음.
